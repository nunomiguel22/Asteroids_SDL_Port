

Console commands
Format: "command argument"

Commands:
"quit" - Exits game
"clear" - Clears console

"init_server port number" - Prepares network to host a game
"init_client" - Prepares network to connect to a game
"send_testpacket message" - send a packet with a message to connected computer, can be read with "receive_testpacket"
"receive_testpacket" - attempts to receive a test_packet, prints "null" on failure