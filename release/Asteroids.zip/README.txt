

Console commands
Format: "command argument"

Commands:
"quit" - Exits game
"clear" - Clears console

"init_server port number" - Prepares network to host a game
"init_client" - Prepares network to connect to a game
